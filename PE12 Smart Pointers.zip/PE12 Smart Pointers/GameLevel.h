#pragma once
class GameLevel
{
private:
	int levelNum;
	float exitLoc;
	float* treasure;
public:
	GameLevel();
	~GameLevel();
};

