#pragma once
#include "Item.h"
class Bow :
    public Item
{
    struct Item;
};

