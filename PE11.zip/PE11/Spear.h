#pragma once
#include "Item.h"
class Spear :
    public Item
{
    struct Item;
};

