#pragma once
#include "Item.h"
class Sword :
    public Item
{
    struct Item;
};

