#pragma once
#include "Item.h"
class Axe :
    public Item
{
    struct Item;
};

