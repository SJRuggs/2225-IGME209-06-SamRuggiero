#pragma once
#include <string>

int iteration(int seats);
int formula(int seats);
int recursion(int seats);
std::string finishLine(int seats);
void details();
void report(int seats);
void wrapper();
